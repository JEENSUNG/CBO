package com.example.sns.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sns.R;

import static com.example.sns.R.layout.activity_reply_list;

public class ReplyListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_reply_list);
    }
}
