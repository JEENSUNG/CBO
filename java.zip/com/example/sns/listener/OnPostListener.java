package com.example.sns.listener;

import com.example.sns.PostInfo;

public interface OnPostListener {
    void onDelete(PostInfo postInfo);
    void onModify();
}
